/* eslint-disable */
import './polyfills';

global.BROWSER = false;
