module.exports = {
  testRegex: 'tests/.*?(test)\\.js$',
  setupFilesAfterEnv: ['<rootDir>/setup.jest.js'],
};
