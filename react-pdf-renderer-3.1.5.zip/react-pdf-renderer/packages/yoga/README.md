<p align="center">
  <img src="https://user-images.githubusercontent.com/5600341/27505816-c8bc37aa-587f-11e7-9a86-08a2d081a8b9.png" height="280px">
</p>

# @react-pdf/yoga

> Prebuilt [yoga-layout](https://github.com/facebook/yoga)

## Acknowledges

This package ship [yoga-wasm-web/asm](https://github.com/shuding/yoga-wasm-web) with commonjs entry

## Install

```
$ npm install @react-pdf/yoga
```

## Usage

```js
import Yoga from '@react-pdf/yoga';
// Same as if imported from yoga-layout
```
