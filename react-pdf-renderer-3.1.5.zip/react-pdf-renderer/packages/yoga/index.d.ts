import { YogaStatic } from 'yoga-wasm-web';

export default YogaStatic;
