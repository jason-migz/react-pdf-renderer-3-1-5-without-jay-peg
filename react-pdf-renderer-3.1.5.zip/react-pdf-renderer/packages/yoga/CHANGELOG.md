# @react-pdf/yoga

## 4.1.0

### Minor Changes

- [#2186](https://github.com/diegomura/react-pdf/pull/2186) [`72435bd`](https://github.com/diegomura/react-pdf/commit/72435bd81afdada5b811a1d82af0c873cfb62fa0) Thanks [@jeetiss](https://github.com/jeetiss)! - update yoga-layout to support flexBasis auto

## 4.0.1

### Patch Changes

- [#2168](https://github.com/diegomura/react-pdf/pull/2168) [`a45355a`](https://github.com/diegomura/react-pdf/commit/a45355afa4568fc01020e520af56eaa1e48dd85b) Thanks [@jeetiss](https://github.com/jeetiss)! - transpile modern js

## 4.0.0

### Major Changes

- [#2105](https://github.com/diegomura/react-pdf/pull/2105) [`a14ca9e`](https://github.com/diegomura/react-pdf/commit/a14ca9e62c9edc37f239558f8dbae29212b0da4d) Thanks [@jeetiss](https://github.com/jeetiss)! - migrate from yoga-layout-prebuilt to yoga-wasm-web

## 3.0.0

### Major Changes

- [#1891](https://github.com/diegomura/react-pdf/pull/1891) [`a5a933c`](https://github.com/diegomura/react-pdf/commit/a5a933c9733e4c77338ef76a2b3545b84a646a81) Thanks [@carlobeltrame](https://github.com/carlobeltrame)! - feat: compatibility with modern web bundlers and browsers

## 2.0.4

### Patch Changes

- [#1581](https://github.com/diegomura/react-pdf/pull/1581) [`04449ab`](https://github.com/diegomura/react-pdf/commit/04449ab352db0cca2155024dd3e8c690e42193ca) Thanks [@jeetiss](https://github.com/jeetiss)! - added changelog with changesets
