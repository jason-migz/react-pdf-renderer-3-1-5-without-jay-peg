// eslint-disable-next-line import/no-unresolved
import initYoga from 'yoga-wasm-web/asm';

export default initYoga();
