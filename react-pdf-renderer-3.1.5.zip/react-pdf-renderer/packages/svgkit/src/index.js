import SVGDocument from './document';

export default SVGDocument;
