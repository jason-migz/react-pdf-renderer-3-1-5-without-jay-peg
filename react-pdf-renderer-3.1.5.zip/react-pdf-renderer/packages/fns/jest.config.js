module.exports = {
  testRegex: 'tests/.*?(test)\\.js$',
};
