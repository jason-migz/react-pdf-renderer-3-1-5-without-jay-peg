module.exports = {
  automock: false,
  testRegex: 'tests/.*?(test)\\.js$',
  setupFiles: ['<rootDir>setupTests.js'],
};
